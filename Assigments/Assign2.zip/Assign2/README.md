# Lecture 5
Lecture 5 code and comments
