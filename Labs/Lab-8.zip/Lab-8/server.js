//I pledge my honor that I have abided by the Stevens Honor System
//Henry Thomas

// We first require our express package
var express = require('express');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var logging = require('./lab8module.js')

// We create our express instance:
var app = express();

app.use(cookieParser());
app.use(bodyParser.json()); // for parsing application/json

// Middleware:
app.use("/api", function(request, response, next) {
    var now = new Date();
    var freshLog = logging.newLog(request.path,request.method,request.cookies,now.toString())
    next();
});

// Route:
app.get("/cookies/addCookie", function(request, response){
  if (!request.query.key || !request.query.value) { 
    response.status(500).send("Error: Invalid key or value.");
    return;
  } else {
  response.cookie(request.query.key,request.query.value);
  response.status(200).send("This succeeded");
  }
});

// We can now navigate to localhost:3000
app.listen(3000, function() {
    console.log('Your server is now listening on port 3000! Navigate to http://localhost:3000 to access it');
});