var exports = module.exports = {};

exports.mongoConfig = {
    serverUrl: "mongodb://localhost:27017/",
    database: "lab8"        
};
